﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace contempMidterm
{
    class Hotel
    {
        public String HotelClass { get; set; }
        public String CityClass { get; set; }
        public Decimal RoomsClass { get; set; }
        public Decimal RateClass { get; set; }

        public override string ToString()
        {
            return $"{HotelClass}, {CityClass}, {RoomsClass}, {RateClass}";
        }
    }
    
}
