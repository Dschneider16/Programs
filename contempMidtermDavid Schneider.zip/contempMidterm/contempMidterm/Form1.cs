﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace contempMidterm
{
    public partial class AdminFrm : Form
    {
        public AdminFrm()
        {
            InitializeComponent();
        }

        private void AdminFrm_Load(object sender, EventArgs e)
        {
            var listHotels = new List<Hotel>
            {
                new Hotel {HotelClass = "Marriot",CityClass = "Cincinnati", RoomsClass = 34, RateClass = 125},
                new Hotel {HotelClass = "red roof inn",CityClass = "Tenesee", RoomsClass = 12, RateClass = 12  },
                new Hotel {HotelClass = "Super Eight",CityClass = "Carolina", RoomsClass = 2, RateClass = 60  }
            };
            listHotels.ForEach ( x =>
            {
                ListHotelsBox.Items.Add(x.ToString());
            });
        }

        private void Addbtn_Click(object sender, EventArgs e)
        {
            var addHotel = new hotelFrm();
            var result = addHotel.ShowDialog();

            if (result == DialogResult.OK)
            {
                var hotel = addHotel.Tag as Hotel;
                ListHotelsBox.Items.Add(addHotel.Tag.ToString());

                MessageBoxSet.Text= "Your selection has been added";
            }
        }
        
    }
}
