﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace contempMidterm
{
    public partial class hotelFrm : Form
    {
        public hotelFrm()
        {
            InitializeComponent();
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SubmitBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsValidData())
                {
                    this.DialogResult = DialogResult.OK;



                    Tag = new Hotel
                    {
                        CityClass = this.CityTxt.Text,
                        HotelClass = this.HotelTxt.Text,
                        RoomsClass = Convert.ToDecimal(this.RoomsTxt.Text),
                        RateClass = Convert.ToDecimal(this.RateTxt.Text)
                    };
                }
            }
            catch (Exception w) { }

            
            
        }
        public bool IsValidData()
        {
            return
                IsPresent(HotelTxt, "Hotel") &&
                IsPresent(CityTxt, "City") &&
                IsDecimal(RoomsTxt, "Room") &&
                IsDecimal(RateTxt, "Rate") &&
                IsWithinRange(RoomsTxt, "Room", 0, 1000)&&
                IsWithinRange(RateTxt, "Rate", 0, 1000);
        }

        public bool IsPresent(TextBox textBox, string name)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(name + " is a required field.", "Entry Error");
                textBox.Focus();
                return false;
            }
            return true;
        }

        public bool IsDecimal(TextBox textBox, string name)
        {
            decimal number = 0m;
            if (Decimal.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(name + " must be an integer.", "Entry Error");
                textBox.Focus();
                return false;
            }
        }

        public bool IsWithinRange(TextBox textBox, string name,
            decimal min, decimal max)
        {
            decimal number = Convert.ToDecimal(textBox.Text);
            if (number <= min || number >= max)
            {
                MessageBox.Show(name + " must be between " + min +
                    " and " + max + ".", "Entry Error");
                textBox.Focus();
                return false;
            }
            return true;
        }
    }
}
