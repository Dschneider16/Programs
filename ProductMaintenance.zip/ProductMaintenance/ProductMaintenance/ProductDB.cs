﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ProductMaintenance
{
    public class ProductDB
    {

        public static Product GetProduct(string productCode)
        {
            var connection = MMABooksDB.GetConnection();
            string SelectStatement = "Select * From Products where productCode = '" + productCode + "'";




            SqlCommand getProduct = new SqlCommand(SelectStatement, connection);





            try
            {
                connection.Open();
                SqlDataReader prodReader =
                    getProduct.ExecuteReader();

                Product product = new Product();
                if (prodReader.Read()) {
                    product.Code = prodReader["ProductCode"].ToString();
                    product.Description = prodReader["Description"].ToString();
                    product.Price = (decimal)prodReader["UnitPrice"];
                    

                   
                }
                return product;

            }
            catch (Exception sqlex)
            {


                  MessageBox.Show(sqlex.StackTrace);
                //Code what happens if and sql error occurs here

                return null;
                
            }
            finally
            {




                connection.Close();

            }
        }

        public static bool UpdateProduct(Product oldProduct,
        Product newProduct)
        {
            SqlConnection connection = MMABooksDB.GetConnection();
            string updateStatement =
                "UPDATE Products " +
                "Description '" + newProduct.Description +"', " +
                "set UnitPrice = '" + newProduct.Price + "', " +
                "Where ProducctCode = '"+ oldProduct.Code+ "', "
             ;
            SqlCommand updateCommand =
                new SqlCommand(updateStatement, connection);
          
            try
            {
                connection.Open();
                updateCommand.ExecuteNonQuery();
                return true;

            }
            catch (SqlException ex)
            {


                MessageBox.Show("Database error # " + ex.Number + ": "
                + ex.Message,  ex.GetType().ToString());
                return false;
            }
            finally
            {
                connection.Close();
            }


        }
        public static bool DeleteProduct(Product product)
        {
            SqlConnection connection = MMABooksDB.GetConnection();
            string deleteStatement =
                "DELETE FROM Products " +
                "WHERE ProductCode = '" + product.Code + "'";
            SqlCommand deleteCommand =
                new SqlCommand(deleteStatement, connection);




            try
            {
                connection.Open();
                deleteCommand.ExecuteNonQuery();
                return true;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;


            }
            finally
            {
                connection.Close();
            }
        }
            public static bool addProduct(Product product)
            {
                SqlConnection connection = MMABooksDB.GetConnection();
                string addStatement =
                    "insert into Products " +
                    "(ProductCode, unitPrice, Description)values( '" + product.Code + "','" + product.Price +" ','" + product.Description + " ')";
                SqlCommand addCommand =
                    new SqlCommand(addStatement, connection);




                try
                {
                    connection.Open();
                    addCommand.ExecuteNonQuery();
                    return true;
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                    return false;


                }
                finally
                {
                    connection.Close();
                }

            }
    }
    
}
