﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductMaintenance
{
    public class MMABooksDB
    {
        

        public static SqlConnection GetConnection()
        {
            String connectionString = "Data Source = (LocalDB)\\MSSQLLocalDB; AttachDbFilename = |DataDirectory|\\MMABooks.mdf; Integrated Security = True;";
             return new SqlConnection(connectionString);
        }

    }
}
