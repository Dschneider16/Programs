using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FutureValue
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsValidData())
                {
                    // try
                    //{ 
                    decimal monthlyInvestment = Convert.ToDecimal(txtMonthlyInvestment.Text);
                    decimal yearlyInterestRate = Convert.ToDecimal(txtInterestRate.Text);
                    int years = Convert.ToInt32(txtYears.Text);

                    int months = years * 12;
                    decimal monthlyInterestRate = yearlyInterestRate / 12 / 100;

                    decimal futureValue = this.CalculateFutureValue(
                        monthlyInvestment, monthlyInterestRate, months);
                    txtFutureValue.Text = futureValue.ToString("c");
                    txtMonthlyInvestment.Focus();
                    // }
                    //catch (StackOverflowException a)
                    //{
                    //    MessageBox.Show("youve got too much money to invest", "entry error");
                    //}
                    //catch (ArithmeticException a)
                    //{
                    //   MessageBox.Show("please enter correct arithmetics", "entry error");
                    //}
                    //catch (FormatException a)
                    //{
                    //   MessageBox.Show("please enter a correct format", "entry error");
                    //}
                    //catch (Exception a)
                    //{
                    //  MessageBox.Show("please enter a correct format", "entry error" + a.StackTrace);

                    //}
                    //  throw new Exception("Monthly investments must be greater than 0.");
                    //if (monthlyInterestRate <= 0)
                    //  throw new Exception("interest Rate must be greater than 0,");
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Please correct the mistakes you have made in the format", "entry error" + a.StackTrace);
            } 
        }


        public bool IsValidData()
        {
            return
                IsPresent(txtMonthlyInvestment, "monthly Investment") &&
                IsDecimal(txtMonthlyInvestment, "Monthly Investment") &&
                IsWithinRange(txtMonthlyInvestment, "Monthly Investment", 1, 1000) &&

                IsPresent(txtInterestRate, "Yearly Interest Rate") &&
                IsDecimal(txtInterestRate, "Yearly Interest Rate") &&
                IsWithinRange(txtInterestRate, "Yearly Interest Rate", 1, 1000) &&

                IsPresent(txtYears, "Number Of Years") &&
                IsInt32(txtYears, "Number Of Years") &&
                IsWithinRange(txtYears, "Number Of Years", 1, 40);

        }

        public bool IsInt32(TextBox textBox, String name)
        {
            int number = 0;
            if (Int32.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(name + " must be an integer.", "entry error");
                    textBox.Focus();
                return false;
            }
        }

        public bool IsPresent(TextBox textBox, String name)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(name + " is a required data field", "entry error");
                textBox.Focus();
                return false;
            }
            return true;
        }
        public bool IsDecimal(TextBox textBox, String name) {
            decimal number = 0m;
            if (Decimal.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(name + " must be a decimal value", "entry error");
                textBox.Focus();
                return false;
            }

        }
        public bool IsWithinRange(TextBox textBox, String name, decimal min, decimal max)
        {
            decimal number = Convert.ToDecimal(textBox.Text);
            if (number < min || number > max)
            {
                MessageBox.Show(name + " must be between " + min + " and " + max + ".", "entry  Error");
                textBox.Focus();
                return false;
            }
            return true;
        }

      


        private decimal CalculateFutureValue(decimal monthlyInvestment,
           decimal monthlyInterestRate, int months)
        {
         
            decimal futureValue = 0m;
            for (int i = 0; i < months; i++)
            {
                futureValue = (futureValue + monthlyInvestment)
                            * (1 + monthlyInterestRate);
            }
            return futureValue;
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}