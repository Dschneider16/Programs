﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class admintFrm : Form
    {
        public static Dictionary<string, List<double>> Students = new Dictionary<string, List<double>>();
        public static int selected;
        

        public admintFrm()
        {
            InitializeComponent();
        }

        
        
        private void Form1_Load(object sender, EventArgs e)
        {

            Students.Add("David", new List<double> { 78, 88, 90 });
            Students.Add("kevin", new List<double> {100, 100, 100 });

            AddToListBox();


        }
        private void AddToListBox()
        {
            foreach (var student in Students)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append(student.Key.ToString());
                sb.Append(" - ");
                for (int i = 0; i < student.Value.Count; i++)
                {
                    sb.Append(student.Value[i]);
                    if (i != student.Value.Count - 1)
                    {
                        sb.Append(", ");
                    }
                }
                listStudentsBox.Items.Add(sb);
                listStudentsBox.SetSelected(0, true);
                UpdateInfo();
            }
        }
        private void UpdateInfo()
        {
            try
            {
                scoreCountTxt.Text = Students.Values.ElementAt(listStudentsBox.SelectedIndex).Count().ToString();
                txtScoreTotal.Text = Students.Values.ElementAt(listStudentsBox.SelectedIndex).Sum().ToString();
                averageTxt.Text = Math.Round(Students.Values.ElementAt(listStudentsBox.SelectedIndex).Average()).ToString();
            }
            catch(Exception)
            {
                txtScoreTotal.Text = "";
                scoreCountTxt.Text = "";
                averageTxt.Text = "";
            }
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {

            Form addStudent = new studentFrm();
             addStudent.ShowDialog();
            listStudentsBox.Items.Clear();
            AddToListBox(); 
           
        }

        private void ExtBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {

            Students.Remove(Students.Keys.ElementAt(listStudentsBox.SelectedIndex));
            listStudentsBox.Items.Clear();
            AddToListBox();
            if (Students.Count == 0)
            {
                txtScoreTotal.Text = "";
                scoreCountTxt.Text = "";
                averageTxt.Text = "";
            }
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            Form updateStudents = new UpdateStudents();
            selected = listStudentsBox.SelectedIndex;
            if (listStudentsBox.Items.Count > 0)
            {
                updateStudents.ShowDialog();
            }
            listStudentsBox.Items.Clear();
            AddToListBox();
        }
        private void listStudentBox_Click(object sender, EventArgs e)
        {
            UpdateInfo();
        }
        private void admintForm_Activated(object sender, EventArgs e)
        {
            UpdateInfo();
        }
       
    };




}
    

