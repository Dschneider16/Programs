﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class update : Form
    {
        public update()
        {
            InitializeComponent();
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if(Double.Parse(updateTxt.Text) >= 0 && Double.Parse(updateTxt.Text) <= 100)
                {
                    UpdateStudents.placeHolder.Values.ElementAt(admintFrm.selected)
                        [UpdateStudents.selected] = Double.Parse(updateTxt.Text);
                    this.Close();
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a number from 0 - 100","");
                    
            }
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
