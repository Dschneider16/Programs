﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class studentFrm : Form
    {
        public static Dictionary<string, List<double>> newStudent = new Dictionary<string, List<double>>();
        List<double> scores = new List<double>();
        public studentFrm()
        {
            InitializeComponent();
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (Double.Parse(txtScore.Text) >= 0 && Double.Parse(txtScore.Text) <= 100)
                {
                scores.Add(Double.Parse(txtScore.Text));
                }
                else
                {
                    MessageBox.Show("Please enter a score from 0 to 100", "entry error");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid number", "entry error");
            }

            txtScoreList.Text = String.Join(", ", scores);
            txtScore.Text = "";
            txtScore.Focus();
        } 
       

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtScore_TextChanged(object sender, EventArgs e)
        {

        }

        private void clearScoreBtn_Click(object sender, EventArgs e)
        {
            scores.Clear();
            txtScore.Text = "";
            txtScoreList.Text = "";
            txtScore.Focus();
           
        }

        private void acceptBtn_Click(object sender, EventArgs e)
        {
            if(Nametxt.Text != "")
            {
                admintFrm.Students.Add(Nametxt.Text, scores);
                this.Close();
            }
            else
            {
                MessageBox.Show("Please enter a correctly formatted name ","entry Error");
            }
        }

        
    }
}
