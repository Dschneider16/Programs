﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class UpdateStudents : Form
    {
        public static Dictionary<string, List<double>> placeHolder;
        public static int selected;
        BindingSource binder = new BindingSource();
        public UpdateStudents()
        {
            InitializeComponent();
        }
        private void UpdateStudents_Activated(object sender, EventArgs e)
        {
            NameTxt.Text = placeHolder.Keys.ElementAt(admintFrm.selected);
            binder.DataSource = placeHolder.Values.ElementAt(admintFrm.selected);
            lstboxScores.DataSource = binder;
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            
            selected = lstboxScores.SelectedIndex;
            Form Update = new update();
            Update.ShowDialog();
            binder.ResetBindings(false);
            
        }
        

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void UpdateStudents_Load(object sender, EventArgs e)
        {
            placeHolder = admintFrm.Students.ToDictionary
                (p => p.Key, p => p.Value.ToList());
        }

        private void ClearBtn_Click(object sender, EventArgs e)
        {
            placeHolder.Values.ElementAt(admintFrm.selected).RemoveRange
                (0, placeHolder.Values.ElementAt(admintFrm.selected).Count);
            binder.ResetBindings(false);
        }

        private void AddScoreBtn_Click(object sender, EventArgs e)
        {
            Form addScore = new addScore();
            addScore.ShowDialog();
            binder.ResetBindings(false);
        }

        private void AcceptBtn_Click(object sender, EventArgs e)
        {
            admintFrm.Students = placeHolder;
            this.Close();
        }

        private void RemoveBtn_Click(object sender, EventArgs e)
        {
            placeHolder.Values.ElementAt(lstboxScores.SelectedIndex).RemoveAt(lstboxScores.SelectedIndex);
            binder.ResetBindings(false);
        }
    }
}
