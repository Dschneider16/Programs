﻿namespace WindowsFormsApp4
{
    partial class studentFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtScore = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.addBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.Nametxt = new System.Windows.Forms.TextBox();
            this.txtScoreList = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.acceptBtn = new System.Windows.Forms.Button();
            this.clearScoreBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtScore
            // 
            this.txtScore.Location = new System.Drawing.Point(142, 87);
            this.txtScore.Name = "txtScore";
            this.txtScore.Size = new System.Drawing.Size(130, 26);
            this.txtScore.TabIndex = 0;
            this.txtScore.TextChanged += new System.EventHandler(this.txtScore_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Student Score";
            // 
            // addBtn
            // 
            this.addBtn.Location = new System.Drawing.Point(313, 82);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(115, 36);
            this.addBtn.TabIndex = 5;
            this.addBtn.Text = "Add";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(193, 243);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(115, 44);
            this.exitBtn.TabIndex = 6;
            this.exitBtn.Text = "Cancel";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Student Name";
            // 
            // Nametxt
            // 
            this.Nametxt.Location = new System.Drawing.Point(142, 26);
            this.Nametxt.Name = "Nametxt";
            this.Nametxt.Size = new System.Drawing.Size(328, 26);
            this.Nametxt.TabIndex = 1;
            // 
            // txtScoreList
            // 
            this.txtScoreList.Enabled = false;
            this.txtScoreList.Location = new System.Drawing.Point(142, 158);
            this.txtScoreList.Name = "txtScoreList";
            this.txtScoreList.Size = new System.Drawing.Size(211, 26);
            this.txtScoreList.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 161);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "Scores list";
            // 
            // acceptBtn
            // 
            this.acceptBtn.Location = new System.Drawing.Point(21, 243);
            this.acceptBtn.Name = "acceptBtn";
            this.acceptBtn.Size = new System.Drawing.Size(115, 44);
            this.acceptBtn.TabIndex = 11;
            this.acceptBtn.Text = "OK";
            this.acceptBtn.UseVisualStyleBackColor = true;
            this.acceptBtn.Click += new System.EventHandler(this.acceptBtn_Click);
            // 
            // clearScoreBtn
            // 
            this.clearScoreBtn.Location = new System.Drawing.Point(393, 152);
            this.clearScoreBtn.Name = "clearScoreBtn";
            this.clearScoreBtn.Size = new System.Drawing.Size(115, 39);
            this.clearScoreBtn.TabIndex = 12;
            this.clearScoreBtn.Text = "Clear Scores";
            this.clearScoreBtn.UseVisualStyleBackColor = true;
            this.clearScoreBtn.Click += new System.EventHandler(this.clearScoreBtn_Click);
            // 
            // studentFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 316);
            this.Controls.Add(this.clearScoreBtn);
            this.Controls.Add(this.acceptBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtScoreList);
            this.Controls.Add(this.Nametxt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtScore);
            this.Name = "studentFrm";
            this.Text = "studentFrm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtScore;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Nametxt;
        private System.Windows.Forms.TextBox txtScoreList;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button acceptBtn;
        private System.Windows.Forms.Button clearScoreBtn;
    }
}