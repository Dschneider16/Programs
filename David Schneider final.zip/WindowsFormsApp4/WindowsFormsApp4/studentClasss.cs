﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp4
{
    public class Student
    {
        public string Name { get; set; }
        
       

       public Student()
        {

        }

       


        public override string ToString()
        {
            return $"{Name} ";
        }
       


    }
    
}
