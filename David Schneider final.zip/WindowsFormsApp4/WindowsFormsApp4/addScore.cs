﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class addScore : Form
    {
        public addScore()
        {
            InitializeComponent();
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            try
            {
            if(Double.Parse(txtScore.Text) >= 0 && Double.Parse(txtScore.Text) <= 100)
                {
                    UpdateStudents.placeHolder.Values.ElementAt(UpdateStudents.selected).Add(Double.Parse(txtScore.Text));
                    this.Close();
                }
                else
                {
                    MessageBox.Show("You must enter a valid number between 0 and 100","Input error");
                }
            }
            catch(FormatException)
            {
                MessageBox.Show("Please enter a valid number","Entry error");
            }
            
        }
    }
}
