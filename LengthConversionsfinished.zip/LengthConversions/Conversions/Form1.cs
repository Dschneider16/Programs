using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Conversions
{
    public partial class Form1 : Form
    {
        public static decimal units = 0m;
        public static decimal conversion = 0m;
        public static decimal conversionRate = 0m;
        public Form1()
        {
            InitializeComponent();
        }
        
        string[,] conversionTable = {
			{"Miles to Kilometers", "Miles", "Kilometers", "1.6093"},
			{"Kilometers to Miles", "Kilometers", "Miles", "0.6214"},
			{"Feet to Meters", "Feet", "Meters", "0.3048"},
			{"Meters to Feet", "Meters", "Feet", "3.2808"},
			{"Inches to Centimeters", "Inches", "Centimeters", "2.54"},
			{"Centimeters to Inches", "Centimeters", "Inches", "0.3937"}
		};
        public bool IsValidData()
        {
            return
            IsPresent(txtLength, "A unit") &&
                IsDecimal(txtLength, "A unit") &&


                IsPresent(txtLength, "Yearly Interest Rate") &&
                IsDecimal(txtLength, "Yearly Interest Rate");
                
               

            
        }
        public bool IsPresent(TextBox textBox, string name)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(name + " is a required field.", "Entry Error");
                textBox.Focus();
                return false;
            }
            return true;
        }

        public bool IsDecimal(TextBox textBox, string name)
        {
            try
            {
                Convert.ToDecimal(textBox.Text);
                return true;
            }
            catch (FormatException)
            {
                MessageBox.Show(name + " must be a decimal number.", "Entry Error");
                textBox.Focus();
                return false;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsValidData())
                {



                    if (conversionTable[0, 0] == cboConversions.Text)
                    {
                        units = Convert.ToDecimal(txtLength.Text);
                        conversion = Convert.ToDecimal(conversionTable[0, 3]) * units;
                        lblCalculatedLength.Text = Convert.ToString(conversion);
                    }
                    else if (conversionTable[1, 0] == cboConversions.Text)
                    {
                        units = Convert.ToDecimal(txtLength.Text);
                        conversion = Convert.ToDecimal(conversionTable[1, 3]) * units;
                        lblCalculatedLength.Text = Convert.ToString(conversion);
                    }
                    else if (conversionTable[2, 0] == cboConversions.Text)
                    {
                        units = Convert.ToDecimal(txtLength.Text);
                        conversion = Convert.ToDecimal(conversionTable[2, 3]) * units;
                        lblCalculatedLength.Text = Convert.ToString(conversion);
                    }
                    else if (conversionTable[3, 0] == cboConversions.Text)
                    {
                        units = Convert.ToDecimal(txtLength.Text);
                        conversion = Convert.ToDecimal(conversionTable[3, 3]) * units;
                        lblCalculatedLength.Text = Convert.ToString(conversion);
                    }
                    else if (conversionTable[4, 0] == cboConversions.Text)
                    {
                        units = Convert.ToDecimal(txtLength.Text);
                        conversion = Convert.ToDecimal(conversionTable[4, 3]) * units;
                        lblCalculatedLength.Text = Convert.ToString(conversion);
                    }
                    else if (conversionTable[5, 0] == cboConversions.Text)
                    {
                        units = Convert.ToDecimal(txtLength.Text);
                        conversion = Convert.ToDecimal(conversionTable[5, 3]) * units;
                        lblCalculatedLength.Text = Convert.ToString(conversion);

                    }
                }
        }
            catch(Exception)
            {
                MessageBox.Show("How did you get here again?","entry error");
            }
    }
        public void ClearInfo()
        {
            lblCalculatedLength.Text = "";
            txtLength.Text = "";
        }
        private void ChkChanged(object sender, EventArgs e)
        {
            


                if (cboConversions.Text == "Miles to Kilometers")
                {
                    lblFromLength.Text = "Miles:";
                    lblToLength.Text = "Kilometers:";
                }
                else if (cboConversions.Text == "Kilometers to Miles")
                {
                    lblFromLength.Text = "Kilometers:";
                    lblToLength.Text = "Miles:";
                }
                else if (cboConversions.Text == "Feet to Meters")
                {
                    lblFromLength.Text = "Feet:";
                    lblToLength.Text = "Meters:";
                }
                else if (cboConversions.Text == "Meters to Feet")
                {
                    lblFromLength.Text = "Meters:";
                    lblToLength.Text = "Feet:";
                }
                else if (cboConversions.Text == "Inches to Centimeters")
                {
                    lblFromLength.Text = "Inches:";
                    lblToLength.Text = "Centimeters:";
                }
                else if (cboConversions.Text == "Centimeters to Inches")
                {
                    lblFromLength.Text = "Centimeters:";
                    lblToLength.Text = "Inches:";
                }
            ClearInfo();
            txtLength.Focus();
        }

        
    }
}